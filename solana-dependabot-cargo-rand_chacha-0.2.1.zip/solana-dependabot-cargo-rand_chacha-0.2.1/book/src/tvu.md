# The Transaction Validation Unit

<img alt="TVU Block Diagram" src="img/tvu.svg" class="center"/>
