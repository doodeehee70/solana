# The Transaction Processing Unit

<img alt="TPU Block Diagram" src="img/tpu.svg" class="center"/>
