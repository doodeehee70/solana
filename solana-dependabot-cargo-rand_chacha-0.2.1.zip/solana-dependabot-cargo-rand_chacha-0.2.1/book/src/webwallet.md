# Example app: Web Wallet

## Build and run a web wallet locally

First fetch the example code:

```sh
$ git clone https://github.com/solana-labs/example-webwallet.git
$ cd example-webwallet
$ TAG=$(git describe --tags $(git rev-list --tags
--max-count=1))
$ git checkout $TAG
```

Next, follow the steps in the git repository's
[README](https://github.com/solana-labs/example-webwallet/blob/master/README.md).
