# Implemented Design Proposals

The following design proposals are fully implemented.
