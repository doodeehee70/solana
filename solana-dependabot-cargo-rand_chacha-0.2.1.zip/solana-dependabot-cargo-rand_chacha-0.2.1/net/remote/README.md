Scripts that run on the remote testnet nodes
