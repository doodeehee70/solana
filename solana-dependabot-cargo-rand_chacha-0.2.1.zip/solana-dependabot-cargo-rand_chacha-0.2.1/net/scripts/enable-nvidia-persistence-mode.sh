#!/usr/bin/env bash
nvidia-smi -pm ENABLED || true
