fn main() -> Result<(), String> {
    solana_install::main()
}
